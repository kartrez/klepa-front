export function priceAfterDiscount(price, percent) {
  const factor = 1 - percent / 100
  const discounted = price * factor
  return discounted * factor
}
