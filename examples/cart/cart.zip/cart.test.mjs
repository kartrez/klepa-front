import assert from 'node:assert/strict'
import test from 'node:test'
import { priceAfterDiscount } from './cart.mjs'

test('одна скидка 10% на 100 рублей', () => {
  assert.equal(priceAfterDiscount(100, 10), 90)
})
